package com.cdac.evillagers.master.entity;

public class StatusMessage {
	public int status;
	public Object message;
	public AdminControl admin;
}
